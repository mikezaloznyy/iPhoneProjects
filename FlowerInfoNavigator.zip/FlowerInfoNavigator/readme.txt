Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 16  FlowerInfoNavigator Project (Hour 13 Activity 1)

Comments: This project should be working fine. Please let me know if you have any issues running it.