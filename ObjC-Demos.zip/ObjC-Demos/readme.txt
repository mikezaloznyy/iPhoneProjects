Name: Mykhaylo (Mike) Zaloznyy
Project: Objective-C Handout

Comments: This was a time consuming assignment that took me about 5 hours to do and digest all the steps. I think this assignment was just right in difficulty and incredibly good. I have learned the tremendous amount of new information, very useful handout!