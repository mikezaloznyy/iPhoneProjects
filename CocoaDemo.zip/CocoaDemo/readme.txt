Name: Mykhaylo (Mike) Zaloznyy
Project: Cocoa Handout

Comments: This was a very interesting assignment and I learned a lot about NSNumber, NSString and memory release concepts. I look forward to further assignments!