Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 10 ImageHop Project (Hour 8 Activity 1)

Comments: I have made the following changes:

* increased the slider range to be from 0.25 to 3.75
* reset the default slider value to be 2.0
* changed the formula to compute animation duration to be 
4 - animationSpeed.value
* changed the formula computing hops per second to use new animation duration
* added a lot of comments to my code
* I have also added the feature where clicking the "Sit Still!" button resets the slider to be at its default location.

Please make sure to test my code on multiple platforms if you have problem running it on the iPhone. (Last homework, you could not run my project on your iPhone but it ran on your iPad.)