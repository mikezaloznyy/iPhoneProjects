Name: Mike Zaloznyy
Project: Assignment7 'HelloNoun' (Hour6 Activity1)

Comments: I enjoyed this project. I think the way Apple implements MVC is very clever. 

I've made the following changes:
1) 'button': "set label" text font changed to Palatino, Bold Italic, Size 18, added shadow to the text and orange background

2) Made 'Hello' label to have orange background

3) '<Noun Goes Here>' is left-aligned and uses a layout of 2 lines. 'Line breaks' is set to 'Word Wrap'.

4) Orientation of the whole view is changed to 'Landscape'.

5) Status bar at the top is changed to 'Translucent Black'.

6) Changed background color for overall view.