Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 9 - Activity 1 Hour 7

Comments: This assignment was interesting. We are making nice progress in this class!