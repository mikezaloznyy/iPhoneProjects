Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 13 FlowerWeb with sounds Project (Hour 10 Activity 2)

Comments: 

I have implemented the following:

I have taken the project from Hour9 "FlowerWeb" and added the sounds to every button. I have created the sounds myself using a program called Adobe Soundbooth. My approach was to annotate every button's click. 

While this project looked quite simple, I have actually been stuck for a long time because I forgot to add the audio framework to frameworks. Xcode kept throwing very confusing error messages. I finally traced the issue. Because of that, I am submitting about 1.5 hrs late, but I am hoping I would not be penalized for that. Thank you.
