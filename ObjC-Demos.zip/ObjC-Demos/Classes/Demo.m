//
//  Demo.m
//  ObjC-Demos
//
//  Created by Mykhaylo Zaloznyy on 2/28/11.
//  Copyright 2011 CSN. All rights reserved.
//

#import "Demo.h"

@implementation Demo

-(void)sayHello {
	NSLog( @"%s", __FUNCTION__ );
}

@end
