//
//  FirstTabViewController.h
//  TabbedCalculation
//
//  Created by Mykhaylo Zaloznyy on 5/10/11.
//  Copyright 2011 CSN. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FirstTabViewController : UIViewController {

}

@end
