Name: Mykhaylo (Mike) Zaloznyy
Project name: HelloWorld (Activity 2 Hour 2 of the textbook)

Comments: While the project itself isn't difficult, it took me a while to set up everything to work correctly. The first problem I've ran into was that my IMac was not equipped for iPhone development. I had to upgrade my Mac OS X 10.5.8 to 10.6.6 by purchasing the upgrade DVD at the Apple store first.

The next issue I ran into was the "Base SDK not found error". The link on StackOverflow website helped me to resolve this problem: http://stackoverflow.com/questions/3393002/there-is-no-sdk-with-the-name-or-path-iphoneos4-0.

I have also found instructor's video on how to submit assignments and discussion board posts to be very helpful in completing of this assignment.