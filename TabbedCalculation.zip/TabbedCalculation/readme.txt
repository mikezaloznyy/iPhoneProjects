Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 15 TabbedCalculation Project (Hour 12 Activity 1)

Comments: This is a late submission of Assignment 15, and I hope it will be accepted. I have really struggled with this project. There were multiple issues:

1) I could not even get the book's example to work. After hours of struggles, I have figured out the the 'view' outlet was not connected properly, so after fixing that, I finally got it to work.

2) The book has an error in volume calculation. The (4/3) needs to be converted to a float, otherwise it leads to integer division. E.g., radius of sphere = 1 produces the volume of 3.14, which is incorrect. I have identified and fixed this error in my project.

3) Passing values back and forth between controllers have not been explained well in the book, so I also struggled with that part. 

The project should be working correctly now, but please let me know if you have any issues with running or compiling of the project.