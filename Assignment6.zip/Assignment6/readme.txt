Name: Mike Zaloznyy
Project: Hour 5. Figure 5.15

Comments: This was relatively easy project due to the fact we just had to follow the book's example. However, I have learned a lot of new information due to the fact I have not worked with Interface builder before.