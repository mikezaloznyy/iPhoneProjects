Name: Mykhaylo (Mike) Zaloznyy
Project: Assignment 14 DateCalc Project (Hour 11 Activity 1)

Comments: I have added the code that initializes the date picker to the current date in ViewDidLoad method, created an outlet for date picker and connected the outlet to the date picker in interface builder. The modification seems to be working great. I look forward to your feedback.


